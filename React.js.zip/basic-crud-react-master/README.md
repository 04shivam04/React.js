# basic-crud-react
This is very basic CRUD app in React contains only one field.This is a just for learning project.

ReactJS CRUD APP is a simple CREATE, READ, UPDATE and DELETE.

Basic app for CRUD operation in react
Use json for rendering.

ReactJS CRUD uses:

[ReactJS] - Javascript Framework

# Installation 
<pre>
$ git clone https://github.com/yogesh-kumawat/basic-crud-react.git
$ cd basic-crud-react
$ npm install
$ npm start
</pre>

# Demo

https://stackblitz.com/edit/react-basic-crud?file=index.js
